from django.shortcuts import render

# Create your view
def request(request):
    return render(request,'request/request.html')