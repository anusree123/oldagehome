from django.conf.urls import url
from request import views
urlpatterns = [
    url('^$', views.request,name='request'),
   ]