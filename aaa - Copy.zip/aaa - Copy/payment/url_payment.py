from django.conf.urls import url
from payment import views
urlpatterns = [
    url('^$', views.payment,name='payment'),
    url('^payment/', views.payment1, name='payment1'),
   ]