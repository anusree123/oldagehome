from django.shortcuts import render
from payment.models import Payment
# Create your view
def payment(request):
    if request.method == "POST":
        obj = Payment()
        obj.name = request.POST.get('name')
        obj.amount= request.POST.get('amount')
        obj.date = request.POST.get('date')


        obj.save()
    return render(request,'payment/payment.html')
def payment1(request):
    objlist = Payment.objects.all()
    context={
        'objval':objlist,
    }
    return  render(request,'payment/viewpayment.html',context)