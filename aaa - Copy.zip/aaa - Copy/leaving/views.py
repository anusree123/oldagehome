from django.shortcuts import render
from leaving.models import Leaving
# Create your view
def leaving(request):
    if request.method == "POST":
        obj = Leaving()
        obj.name = request.POST.get('name')
        obj.dob = request.POST.get('DOB')
        obj.adress = request.POST.get('adress')
        obj.reason= request.POST.get('reason')
        obj.date = request.POST.get('date')

        obj.save()
    return render(request,'leaving/leaving.html')
def leaving1(request):
    objlist = Leaving.objects.all()
    context={
        'objval':objlist,
    }
    return  render(request,'leaving/viewleaving.html',context)