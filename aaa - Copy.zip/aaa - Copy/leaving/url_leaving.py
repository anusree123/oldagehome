from django.conf.urls import url
from leaving import views
urlpatterns = [
    url('^$', views.leaving,name='leaving'),
    url('^leaving/', views.leaving1, name='leaving1'),
   ]