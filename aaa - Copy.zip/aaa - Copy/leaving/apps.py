from django.apps import AppConfig


class LeavingConfig(AppConfig):
    name = 'leaving'
