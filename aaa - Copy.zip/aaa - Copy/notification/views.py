from django.shortcuts import render
from notification.models import Notification
# Create your view
def notification(request):
    if request.method == "POST":
        obj = Notification()
        obj.description = request.POST.get('description')
        obj.date = request.POST.get('date')


        obj.save()
    return render(request,'notification/notification.html')
def notification1(request):
    objlist = Notification.objects.all()
    context={
        'objval':objlist,
    }
    return  render(request,'notification/viewnotification.html',context)