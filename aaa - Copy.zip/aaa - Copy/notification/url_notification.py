from django.conf.urls import url
from notification import views
urlpatterns = [
    url('^$', views.notification,name='notification'),
    url('^notification/', views.notification1, name='notification1'),
   ]