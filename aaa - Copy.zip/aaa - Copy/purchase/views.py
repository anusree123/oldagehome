from django.shortcuts import render
from purchase.models import Purchase
# Create your view
def purchase(request):
    if request.method == "POST":
        obj = Purchase()
        obj.item = request.POST.get('item')
        obj.date= request.POST.get('date')
        obj.amount = request.POST.get('amount')


        obj.save()
    return render(request,'purchase/purchase.html')
def purchase1(request):
    objlist = Purchase.objects.all()
    context={
        'objval':objlist,
    }
    return  render(request,'purchase/viewpurchase.html',context)