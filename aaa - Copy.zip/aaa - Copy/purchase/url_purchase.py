from django.conf.urls import url
from purchase import views
urlpatterns = [
    url('^$', views.purchase,name='purchase'),
    url('^purchase/', views.purchase1, name='purchase1'),
   ]