from django.shortcuts import render
from booking.models import Donationbooking

from django.db import connection
# Create your view
def booking(request):
    if request.method == "POST":
        obj = Donationbooking()
        obj.name = request.POST.get('name')
        obj.dob = request.POST.get('DOB')
        obj.gender = request.POST.get('adress')
        obj.type= request.POST.get('Donation Type')
        obj.date = request.POST.get('date')
        obj.approval = request.POST.get('approval')
        obj.save()
    return render(request,'booking/booking.html')
def booking1(request):
    objlist = connection.cursor()
    objlist.execute(
        "SELECT userreg.*,donationbooking.* FROM `userreg`,`donationbooking` WHERE userreg.uid=donationbooking.uid")
    context = {
        'objval': objlist.fetchall(),
    }



    # objlist = Donationbooking.objects.all()
    # context={
    #     'objval':objlist,
    # }
    return  render(request,'booking/viewbooking.html',context)