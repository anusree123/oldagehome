from django.conf.urls import url
from booking import views
urlpatterns = [
    url('^$', views.booking,name='booking'),
    url('^booking/', views.booking1, name='booking1'),
   ]