from django.shortcuts import render
from staffregistration.models import Staffreg
from login.models import Login
import datetime
from django.db.models import Max

# Create your views here
def staffregistration(request):
    if request.method == "POST":
        obj = Staffreg()
        ob = Login()
        sid = Staffreg.objects.all().aggregate(Max('sid'))
        sidd = list(sid.values())[0]
        siddv = ''

        # for character assigied auto inctement id generttion
        # if not (sidd is None):
        #   siddv="m"+str(sidd+1)
        # else:
        #     siddv="m1"
        #     sidd=0

        obj.sid = sidd + 1
        ob.uid = sidd+1
        ob.uname = request.POST.get('email')
        ob.password = request.POST.get('password')
        ob.type = "staff"
        ob.save()






        obj.name=request.POST.get('name')
        obj.dob = request.POST.get('DOB')
        obj.email = request.POST.get('email')
        obj.phno = request.POST.get('phone number')
        obj.gender = request.POST.get('Gender')

        obj.save()

    return render(request,'staffregistration/staffreg.html')
def staffregi(request):
    objlist = Staffreg.objects.all()
    context={
        'objval':objlist,
    }
    return  render(request,'staffregistration/viewstaffregistration.html',context)