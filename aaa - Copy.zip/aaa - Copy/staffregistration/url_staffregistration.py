from django.conf.urls import url
from staffregistration import views
urlpatterns = [
    url('^$', views.staffregistration,name='staffregistration'),
    url(r'^staff/', views.staffregi, name='staffregi'),

   ]