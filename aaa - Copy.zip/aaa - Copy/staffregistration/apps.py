from django.apps import AppConfig


class StaffregistrationConfig(AppConfig):
    name = 'staffregistration'
