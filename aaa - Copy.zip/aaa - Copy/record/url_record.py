from django.conf.urls import url
from record import views
urlpatterns = [
    url('^$', views.record,name='record'),
    url('^record/', views.record1, name='record1'),
   ]