from django.shortcuts import render
from record.models import Record
# Create your view
def record(request):
    if request.method == "POST":
        obj = Record()
        obj.name = request.POST.get('name')
        obj.dob = request.POST.get('DOB')
        obj.adress = request.POST.get('Address')
        obj.phno = request.POST.get('phone number')
        obj.gender = request.POST.get('Gender')
        obj.save()
    return render(request,'record/record.html')
def record1(request):
    objlist = Record.objects.all()
    context={
        'objval':objlist,
    }
    return  render(request,'record/viewrecord.html',context)