from django.apps import AppConfig


class RecordConfig(AppConfig):
    name = 'record'
