from django.shortcuts import render
from userregistration.models import Userreg
from login.models import Login
import datetime
from django.db.models import Max

# Create your view
def userregistration(request):
    if request.method == "POST":
        obj = Userreg()
        ob = Login()
        sid = Userreg.objects.all().aggregate(Max('uid'))
        sidd = list(sid.values())[0]
        siddv = ''

        # for character assigied auto inctement id generttion
        # if not (sidd is None):
        #   siddv="m"+str(sidd+1)
        # else:
        #     siddv="m1"
        #     sidd=0

        obj.uid = sidd + 1
        ob.uid = sidd + 1
        ob.uname = request.POST.get('E-mail')
        ob.password = request.POST.get('Password')
        ob.type = "user"
        ob.save()

        obj.name = request.POST.get('name')
        obj.dob = request.POST.get('dob')
        obj.email = request.POST.get('E-mail')
        obj.pno = request.POST.get('phone number')
        obj.type = request.POST.get('type')
        obj.relation = request.POST.get('relationship')

        obj.save()

    return render(request,'userregistration/userreg.html')
def userregi(request):
    objlist =Userreg.objects.all()
    context={
        'objval':objlist,
    }
    return  render(request,'userregistration/viewusereg.html',context)