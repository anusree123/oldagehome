from django.conf.urls import url
from userregistration import views
urlpatterns = [
    url('^$', views.userregistration,name='userregistration'),
    url('^user/', views.userregi,name='userregi'),
   ]