from django.conf.urls import url
from services import views
urlpatterns = [
    url('^$', views.services,name='services'),
    url('^services/', views.services1, name='services1'),
   ]