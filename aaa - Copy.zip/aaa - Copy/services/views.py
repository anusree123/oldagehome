from django.shortcuts import render
from django.http import HttpResponse
from services.models import Services
# Create your view
def services(request):
    if request.method == "POST":
        obj = Services()
        obj.service = request.POST.get('service')
        obj. description = request.POST.get('description')



        obj.save()
    return render(request,'services/service.html')
def services1(request):
    objlist = Services.objects.all()
    context={
        'objval':objlist,
    }
    return render(request,'services/viewservice.html',context)