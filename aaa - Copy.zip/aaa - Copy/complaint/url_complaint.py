from django.conf.urls import url
from complaint import views
urlpatterns = [
    url('^$', views.complaint,name='complaint'),
    url('^complaint/', views.complaint1, name='complaint1'),
   ]