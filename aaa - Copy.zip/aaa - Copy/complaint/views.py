from django.shortcuts import render
from complaint.models import Complaint
# Create your view
def complaint(request):
    if request.method == "POST":
        obj = Complaint()
        obj.complaint = request.POST.get('Complaint')
        obj.Date = request.POST.get('Date')


        obj.save()
    return render(request,'complaint/complaint.html')
def complaint1(request):
    objlist = Complaint.objects.all()
    context={
        'objval':objlist,
    }
    return  render(request,'complaint/complaintview.html',context)