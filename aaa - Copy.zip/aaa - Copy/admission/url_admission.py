from django.conf.urls import url
from admission import views
urlpatterns = [
    url('^$', views.admission,name='admission'),
    url('^admission/', views.admission1, name='admission1'),
   ]