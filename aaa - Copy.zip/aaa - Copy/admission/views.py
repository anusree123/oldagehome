from django.shortcuts import render
from admission.models import Admission
# Create your view
def admission(request):
    if request.method == "POST":
        obj = Admission()
        obj.name = request.POST.get('name')
        obj.dob  = request.POST.get('dob')
        obj.adress = request.POST.get('Address')
        obj.phno= request.POST.get('Phonenumber')
        obj.save()
    return render(request,'admission/admission.html')
def admission1(request):
    objlist = Admission.objects.all()
    context={
        'objval':objlist,
    }
    return  render(request,'admission/viewadmission.html',context)
