from django.apps import AppConfig


class AdmissionConfig(AppConfig):
    name = 'admission'
