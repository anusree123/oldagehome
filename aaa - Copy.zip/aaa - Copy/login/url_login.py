from django.conf.urls import url
from login import views
urlpatterns = [
    url('^$', views.login,name='login'),
    url('^adminhome/', views.adminhome, name='adminhome'),
    url('^userhome/', views.userhome, name='userhome'),
    url('^staffhome/', views.staffhome, name='staffhome'),

   ]