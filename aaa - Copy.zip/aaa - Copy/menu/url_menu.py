from django.conf.urls import url
from menu import views
urlpatterns = [
    url('^$', views.menu,name='menu'),
   ]