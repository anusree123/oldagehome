from django.shortcuts import render

# Create your view
def menu(request):
    return render(request,'menu/menu.html')